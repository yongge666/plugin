<?php return array (
  'email_type' => '1',
  'email_safe' => '',
  'mail_address' => 'ddw365@sunupedu.com',
  'smtp' => '',
  'smtp_user' => '',
  'smtp_pwd' => '',
  'smtp_port' => '',
  'order_by' => 'price',
  'order_type' => 'desc',
  'list_type' => 'win',
  'auto_finish' => '1',
  'index_slide' => 'a:4:{i:0;a:3:{s:4:"name";s:30:"点读王—高中听力系列";s:3:"url";s:24:"http://www.sunupedu.com/";s:3:"img";s:39:"upload/2015/06/30/20150630031812987.jpg";}i:1;a:3:{s:4:"name";s:33:"金指课堂—英语同步系列";s:3:"url";s:24:"http://www.sunupedu.com/";s:3:"img";s:39:"upload/2015/06/30/20150630030858108.jpg";}i:2;a:3:{s:4:"name";s:30:"点读王—初中听力系列";s:3:"url";s:24:"http://www.sunupedu.com/";s:3:"img";s:39:"upload/2015/06/29/20150629061904146.jpg";}i:3;a:3:{s:4:"name";s:15:"尚普点读王";s:3:"url";s:24:"http://www.sunupedu.com/";s:3:"img";s:39:"upload/2015/06/29/20150629061621326.jpg";}}',
  'name' => '尚普商城',
  'url' => 'http://www.sunupedu.com',
  'master' => '',
  'qq' => '',
  'email' => 'ddw365@sunupedu.com',
  'mobile' => '',
  'phone' => '027-83363235',
  'address' => '',
  'site_footer_code' => '<p class=\\"links\\">	<a href=\\"\\">关于我们</a>|<a href=\\"\\">常见问题</a>|<a href=\\"\\">安全交易</a>|<a href=\\"\\">购买流程</a>|<a href=\\"\\">如何付款</a>|<a href=\\"\\">联系我们</a>|<a href=\\"\\">合作提案</a> </p><p class=\\"footer\\">	Copyright © 2008-2015 <u><span>鄂ICP备14012156号</span></u></p><p class=\\"footer\\">	<span>武汉尚普教育咨询有限公司 <a href=\\"http://www.sunupedu.com/index.php?controller=systemadmin&amp;action=index\\" target=\\"_blank\\">后 台 管 理</a></span></p><script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement(\\"script");
  hm.src = \\"//hm.baidu.com/hm.js?68b2d5a06bde1fac9101cb8e4bdd0769\\";
  var s = document.getElementsByTagName(\\"script\\")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>',
  'tax' => '10',
  'stockup_time' => '1',
  'index_seo_title' => '',
  'index_seo_keywords' => '',
  'index_seo_description' => '',
  'goods_no_pre' => 'sp',
  'service_online' => 'a:1:{i:0;a:2:{s:4:"name";s:13:"尚普商城2";s:2:"qq";s:9:"564787900";}}',
  'test_address' => '',
  'freightid' => '',
  'freightkey' => '',
)?>