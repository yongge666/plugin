<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="<?php echo IUrl::creatUrl("")."views/".$this->theme."/skin/".$this->skin."/css/admin.css";?>" />
<script type="text/javascript" charset="UTF-8" src="/runtime/_systemjs/jquery/jquery-1.11.3.min.js"></script><script type="text/javascript" charset="UTF-8" src="/runtime/_systemjs/jquery/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" charset="UTF-8" src="/runtime/_systemjs/artdialog/artDialog.js"></script><script type="text/javascript" charset="UTF-8" src="/runtime/_systemjs/artdialog/plugins/iframeTools.js"></script><link rel="stylesheet" type="text/css" href="/runtime/_systemjs/artdialog/skins/default.css" />
</head>
<body style='width:420px;min-height:120px;'>
<div class="pop_win">
	<div class="content">
		<form action="<?php echo IFilter::act(IReq::get('callback'),'url');?>" method='post' enctype='multipart/form-data'>
			<table class='form_table'>
				<colgroup>
					<col width="120px" />
					<col />
				</colgroup>

				<tr>
					<td class="t_r">选择图片文件：</td>
					<td><input type='file' class='file' name='attach' /></td>
				</tr>
			</table>
		</form>
	</div>
</div>
</body>
</html>