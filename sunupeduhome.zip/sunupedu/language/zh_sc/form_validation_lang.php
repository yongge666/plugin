<?php
$prefix = 'fv_';
return array(
	$prefix.'email'		=>'格式不正确',
	$prefix.'tel'		=>'手机验证不通过',
	$prefix.'qq'		=>'qq验证不通过',
	$prefix.'id'		=>'ID验证不通过',
	$prefix.'ip'		=>'IP验证不通过',
	$prefix.'ip'		=>'IP验证不通过',
	$prefix.'zip'		=>'ZIP验证不通过',
	$prefix.'phone'		=>'电话验证不通过',
	$prefix.'required'	=>'不能为空',
);
