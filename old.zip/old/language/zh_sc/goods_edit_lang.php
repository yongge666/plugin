<?php
$prefix = 'add_';
return array(
	$prefix.'goods_name'		=>'商品名称：',
	$prefix.'goods_model'		=>'商品类型：',
	$prefix.'attribute'			=>'商品标签：',
	$prefix.'name_note'			=>'* 商品名称（必填）',
	$prefix.'code_note'			=>'商品编号可以有效管理商品',
	$prefix.'required_note'		=>'商品编号可以有效管理商品',
	$prefix.'label_name'		=>'商品名称',
	$prefix.'label_code'		=>'商品模型',
);
