<?php
return array(
	'name'    => '锦绣前程首款皮肤',
	'author'  => 'Jooyea',
	'time'    => '2011-01-01',
	'version' => '2.0',
	'thumb'   => 'preview.jpg',
	'info'    => 'Jooyea旗下，IwebShop产品锦绣前程首款默认皮肤方案，此主题适用于IwebShop 2.0.× 系列产品',
);
?>