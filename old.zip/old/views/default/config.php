<?php
return array(
	'name'    => '锦绣前程',
	'author'  => 'aircheng',
	'time'    => '2014/12/29 10:03:05',
	'version' => '3.0',
	'thumb'   => 'preview.jpg',
	'info'    => 'Jooyea旗下，IwebShop产品首款默认主题方案，此主题适用于IwebShop 3.0.0 系列产品',
);
?>