<?php
/**
 * @copyright (c) 2011 jooyea.cn
 * @file goods.php
 * @author chendeshan
 * @date 2011-9-30 13:49:22
 * @version 0.6
 */
class APIGoods
{

}