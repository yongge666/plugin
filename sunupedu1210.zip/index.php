<?php
$host_url = isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$root_path =  str_replace("\\","/", dirname(__file__));
define('BASE_URL', 'http://'.$host_url.'/');
define('BASE_PATH', $root_path.'/');   //D:/WWW/sunupedu
$iweb = dirname(__FILE__)."/lib/iweb.php";
$config = dirname(__FILE__)."/config/config.php";
require($iweb);
IWeb::createWebApp($config)->run();
?>