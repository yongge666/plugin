<?php
mysql_connect("localhost:3306","root","spsqlmima");//����MySQL
mysql_select_db("yuyue");//ѡ�����ݿ�
mysql_query("SET NAMES 'utf8'");
mysql_query("SET CHARACTER_SET_CLIENT=utf8");
mysql_query("SET CHARACTER_SET_RESULTS=utf8");
?>