﻿<html>
 <head>
<meta charset="utf-8" />
 <title>预约首页</title>
 <link href="./style.css" rel="stylesheet" />
 </head>
 <body>
<br>
试听课一般安排在周六上午10:00，每人限免费试听1次；
<br>

<a href="./yuyue.php">进入在线预约</a><br>

</body>
</html>