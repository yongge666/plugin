<?php
return array(
	'name' => '中文(简体)',
);
?>